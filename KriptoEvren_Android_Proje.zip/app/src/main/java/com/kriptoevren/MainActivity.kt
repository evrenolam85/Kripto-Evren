package com.kriptoevren
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
val BG=Color(0xFF080B14); val CARD=Color(0xFF111827); val CYAN=Color(0xFF28D7FF); val GREEN=Color(0xFF25D17F); val MUTED=Color(0xFF8B96AA)
class MainActivity:ComponentActivity(){override fun onCreate(b:Bundle?){super.onCreate(b);setContent{App()}}}
@Composable fun App(){MaterialTheme(colorScheme=darkColorScheme(background=BG,surface=CARD,primary=CYAN)){Scaffold(containerColor=BG,bottomBar={NavigationBar(containerColor=Color(0xFF0D1220)){NavigationBarItem(true,{},icon={Icon(Icons.Default.Home,"")},label={Text("Ana Sayfa")});NavigationBarItem(false,{},icon={Icon(Icons.Default.ShowChart,"")},label={Text("Piyasa")});NavigationBarItem(false,{},icon={Icon(Icons.Default.AccountBalanceWallet,"")},label={Text("Portföy")});NavigationBarItem(false,{},icon={Icon(Icons.Default.Article,"")},label={Text("Haberler")})}}){p->Column(Modifier.fillMaxSize().padding(p).padding(16.dp),verticalArrangement=Arrangement.spacedBy(14.dp)){Header();Markets();Season();Text("AL Ön İzlemesi",color=Color.White,fontSize=20.sp,fontWeight=FontWeight.Bold);Text("RSI + aylık değişim + kısa vadeli momentum",color=MUTED,fontSize=12.sp);Coin("GRT","The Graph","0,689 ₺","RSI 31 • Dip bölgesi");Coin("ZK","ZKsync","0,45 ₺","RSI 34 • İzleme");Coin("GLMR","Moonbeam","1,02 ₺","RSI 38 • Momentum");Portfolio();News()}}}}
@Composable fun Header(){Row(verticalAlignment=Alignment.CenterVertically,modifier=Modifier.fillMaxWidth()){Box(Modifier.size(48.dp).background(Color(0xFF101A2D),RoundedCornerShape(14.dp)),contentAlignment=Alignment.Center){Text("◎",color=CYAN,fontSize=30.sp)};Spacer(Modifier.width(12.dp));Column(Modifier.weight(1f)){Text("KRİPTO EVREN",color=Color.White,fontWeight=FontWeight.Bold,fontSize=20.sp);Text("Piyasanın nabzı burada",color=MUTED,fontSize=12.sp)};Icon(Icons.Default.Notifications,"",tint=Color.White)}}
@Composable fun Markets(){Row(horizontalArrangement=Arrangement.spacedBy(10.dp)){Market("₿  BTC","$83.500","+2,4%");Market("Ξ  ETH","$3.245","+1,8%")}}
@Composable fun Market(a:String,b:String,c:String){Card(Modifier.weight(1f),colors=CardDefaults.cardColors(CARD),shape=RoundedCornerShape(18.dp)){Column(Modifier.padding(15.dp)){Text(a,color=CYAN,fontWeight=FontWeight.Bold);Text(b,color=Color.White,fontSize=20.sp,fontWeight=FontWeight.Bold);Text(c,color=GREEN,fontWeight=FontWeight.Bold)}}}
@Composable fun Season(){Card(colors=CardDefaults.cardColors(Color(0xFF101A2D)),shape=RoundedCornerShape(18.dp)){Column(Modifier.padding(17.dp)){Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text("ALTSEASON",color=Color.White,fontWeight=FontWeight.Bold,fontSize=18.sp);Text("%42",color=CYAN,fontSize=27.sp,fontWeight=FontWeight.Bold)};Spacer(Modifier.height(10.dp));LinearProgressIndicator({.42f},Modifier.fillMaxWidth().height(8.dp),color=CYAN,trackColor=Color(0xFF263247))}}}
@Composable fun Coin(s:String,n:String,p:String,r:String){Card(colors=CardDefaults.cardColors(CARD),shape=RoundedCornerShape(16.dp)){Row(Modifier.padding(13.dp),verticalAlignment=Alignment.CenterVertically){Box(Modifier.size(40.dp).background(Color(0xFF1B2538),RoundedCornerShape(12.dp)),contentAlignment=Alignment.Center){Text(s.take(2),color=CYAN,fontWeight=FontWeight.Bold)};Spacer(Modifier.width(12.dp));Column(Modifier.weight(1f)){Text(n,color=Color.White,fontWeight=FontWeight.Bold);Text(p,color=MUTED,fontSize=12.sp)};Text(r,color=GREEN,fontSize=11.sp,fontWeight=FontWeight.Bold)}}}
@Composable fun Portfolio(){Card(colors=CardDefaults.cardColors(CARD),shape=RoundedCornerShape(18.dp)){Column(Modifier.padding(16.dp)){Text("PORTFÖYÜM",color=MUTED,fontSize=12.sp);Text("— ₺",color=Color.White,fontSize=26.sp,fontWeight=FontWeight.Bold);Text("GRT • ZK • HBAR • GLMR • ANKR • MEME • ARPA • SKALE",color=MUTED,fontSize=10.sp)}}}
@Composable fun News(){Card(colors=CardDefaults.cardColors(CARD),shape=RoundedCornerShape(18.dp)){Row(Modifier.padding(16.dp),verticalAlignment=Alignment.CenterVertically){Icon(Icons.Default.Bolt,"",tint=CYAN);Spacer(Modifier.width(10.dp));Column{Text("Önemli gelişmeler",color=Color.White,fontWeight=FontWeight.Bold);Text("Ortaklık, listeleme ve piyasa haberleri",color=MUTED,fontSize=12.sp)}}}}
